package org.aguzman.springcloud.msvc.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
